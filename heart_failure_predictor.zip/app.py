
from flask import Flask, render_template, request
import pickle
import numpy as np

# Load heart failure prediction model
model = pickle.load(open('model1.pkl', 'rb'))

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('crop4.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        age = float(request.form.get('age'))
        anaemia = int(request.form.get('anaemia'))
        creatinine_phosphokinase = float(request.form.get('cpk'))
        diabetes = int(request.form.get('diabetes'))
        ejection_fraction = float(request.form.get('ef'))
        high_blood_pressure = int(request.form.get('hbp'))
        platelets = float(request.form.get('platelets'))
        serum_creatinine = float(request.form.get('serum_creatinine'))
        serum_sodium = float(request.form.get('serum_sodium'))
        sex = int(request.form.get('sex'))
        smoking = int(request.form.get('smoking'))

        features = np.array([
            age, anaemia, creatinine_phosphokinase, diabetes, ejection_fraction,
            high_blood_pressure, platelets, serum_creatinine, serum_sodium, sex, smoking
        ]).reshape(1, -1)

        prediction = model.predict(features)[0]
        result = "Patient is likely to die" if prediction == 1 else "Patient is likely to survive"

        return render_template('crop4.html', result=result)
    except Exception as e:
        return render_template('crop4.html', result=f"Error: {str(e)}")

if __name__ == '__main__':
    app.run(debug=True, port=5001)
